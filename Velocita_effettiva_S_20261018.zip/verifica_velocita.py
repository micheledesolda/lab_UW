#!/usr/bin/env python3
"""Controlli su segno, ritardi frazionari, guadagno e calibrazione assoluta."""
import unittest
import numpy as np
from velocita_effettiva import packet_delay,convert_delay


class DelayTests(unittest.TestCase):
    def setUp(self):
        self.t=np.arange(0.,8.,.04)
        self.pulse=lambda x: np.exp(-((x-3.)/.5)**2)*np.cos(2*np.pi*1.3*(x-3.))
        self.reference=self.pulse(self.t)

    def test_sign_and_fractional_shift(self):
        for shift in [.123,-.087,0.]:
            signal=self.pulse(self.t-shift)
            measured,corr=packet_delay(signal,self.reference,.04)
            self.assertAlmostEqual(measured,shift,delta=1e-5)
            self.assertGreater(corr,.999)

    def test_positive_amplitude_does_not_move_delay(self):
        signal=self.pulse(self.t-.123)
        a=packet_delay(signal,self.reference,.04)[0]
        b=packet_delay(signal*7.2,self.reference*.003,.04)[0]
        self.assertAlmostEqual(a,b,places=12)

    def test_reversal_reverses_sign(self):
        signal=self.pulse(self.t-.123)
        a=packet_delay(signal,self.reference,.04)[0]
        b=packet_delay(self.reference,signal,.04)[0]
        self.assertAlmostEqual(a,-b,places=10)

    def test_same_medium_returns_steel_velocity(self):
        delay=packet_delay(self.reference,self.reference,.04)[0]
        T,V=convert_delay(6.3,.32,delay)
        self.assertAlmostEqual(float(T),6.3/.32,places=9)
        self.assertAlmostEqual(float(V),3200.,places=6)

    def test_known_travel_time_after_source_offset(self):
        # La sorgente ha un massimo a 3 µs, ma non deve entrare in D/c.
        distance=6.3;reference_speed=.32;true_speed=.30
        delay=distance/true_speed-distance/reference_speed
        measured,_=packet_delay(self.pulse(self.t-delay),self.reference,.04)
        T,V=convert_delay(distance,reference_speed,measured)
        self.assertAlmostEqual(float(V),true_speed*1e4,delta=.002)

    def test_reject_zero_trace(self):
        with self.assertRaises(ValueError):packet_delay(np.zeros_like(self.t),self.reference,.04)


if __name__=='__main__':unittest.main(verbosity=2)
