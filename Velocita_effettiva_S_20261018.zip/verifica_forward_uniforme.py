#!/usr/bin/env python3
"""Verifica fisica del riferimento e della velocità su un mezzo uniforme.

Uso: python verifica_forward_uniforme.py /percorso/simulation_setup.py /percorso/fd1d.py
I file indicati devono essere quelli del solver usato dalla run.
"""
import argparse,importlib.util,json
from types import SimpleNamespace
from pathlib import Path
import numpy as np
from velocita_effettiva import reference_trace,packet_delay,convert_delay


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m);return m


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('setup',type=Path);p.add_argument('fd',type=Path);args=p.parse_args()
    setup=load(args.setup,'test_setup');fd=load(args.fd,'test_fd')
    ns={n:getattr(setup,n) for n in ['SimulationTime','Source1D','Receiver1D']}
    ns['finite_difference_1d_receiver_trace']=fd.finite_difference_1d_receiver_trace
    time=np.arange(0.,6.0001,.04);st=np.arange(0.,1.5001,.01)
    stf=(1-2*(np.pi*1.3*(st-.6))**2)*np.exp(-(np.pi*1.3*(st-.6))**2)
    handler=SimpleNamespace(metadata={'time_ax_waveform':st},waveform_data=stf)
    params=dict(embedding_mode='effective_surface',source_injection='body_force',
                receiver_quantity='velocity',boundary_condition='free',max_velocity2simulate=.33,
                side1_density_g_cm3=7.85,source_receiver_config={})
    context=dict(params=params,assembly_dict={'wave_type':'_s','side1_params':{'velocity_s':.32}},
                 stf_handler=handler,uw_data_handler=SimpleNamespace(metadata={'time_ax_waveform':time}))
    results=[]
    for n in [251,501]:
        x=np.linspace(0.,1.,n)
        global_row={'analysis_runtime':{'simulation':{'maximum_damping':.0002142857142857143}}}
        ref=reference_trace(ns,context,x,global_row)
        params2=dict(params);context2=dict(context)
        context2['assembly_dict']={'wave_type':'_s','side1_params':{'velocity_s':.28}}
        # La stessa funzione produce qui la traccia di un mezzo con c=.28.
        # La conversione conserva però la calibrazione del riferimento c=.32.
        model=reference_trace(ns,context2,x,global_row)
        lag,cor=packet_delay(model['trace'],ref['trace'],.04)
        T,V=convert_delay(ref['distance_cm'],ref['speed_cm_us'],lag)
        error=float(V)-2800.
        results.append(dict(grid_points=n,delay_us=lag,expected_delay_us=1/.28-1/.32,
                            velocity_m_s=float(V),expected_velocity_m_s=2800.,
                            error_m_s=error,correlation=cor))
        assert abs(error)<3.,results[-1]
    assert abs(results[-1]['error_m_s'])<abs(results[0]['error_m_s'])
    output=Path(__file__).resolve().parent/'verifica_forward_uniforme.json'
    output.write_text(json.dumps({'results':results,'passed':True,
        'limits':'Verifica sintetica uniforme: non è un controllo sul dataset sperimentale né una stima del suo errore.'},indent=2))
    print(output.read_text())


if __name__=='__main__':main()
