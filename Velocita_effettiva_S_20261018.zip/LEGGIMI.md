# Velocità effettiva del pacchetto S

Questo pacchetto aggiunge al confronto delle mappe il calcolo della velocità
effettiva dal **sintetico completo già accettato**, conservando gli effetti
di densità, viscosità, interfacce e sorgente presenti nel forward della run.
Non usa l'integrale elastico ∫dz/v né una frequenza scelta per far coincidere
le curve.

## Definizione del calcolo

Il mezzo è dispersivo: non esiste una sola velocità scalare indipendente dalla
frequenza e dal metodo di misura. Per seguire il pacchetto della tua sorgente
si definisce qui una velocità operativa, basata sul ritardo per correlazione.

1. Si recuperano dal pickle le tracce accettate delle sole onde effettivamente
   invertite. La loro scala di ampiezza è quella della run.
2. Si esegue **un forward di riferimento per geometria distinta**, sulla
   stessa griglia e con la stessa sorgente S, rendendo omogeneo in acciaio
   l'intero percorso. Velocità e densità dell'acciaio sono lette dalle
   impostazioni esistenti. Nel file esaminato la griglia resta la stessa per
   tutte le 117 inversioni: basta un riferimento.
3. Si misura il ritardo δT della traccia accettata rispetto a questo riferimento,
   mediante il massimo positivo della correlazione normalizzata. Si ripete
   identico calcolo per la corrispondente onda registrata.
4. Alla differenza si aggiunge il tempo noto del percorso omogeneo:

\[
T_{\rm eff}(t)=\frac{D(t)}{c_{\rm acciaio}}+
\underset{\delta}{\arg\max}\,
\frac{\langle r_t(\tau),r_{\rm acciaio}(\tau-\delta)\rangle}
{\|r_t\|_2\|r_{\rm acciaio}\|_2},
\qquad
v_{\rm eff}(t)=\frac{D(t)}{T_{\rm eff}(t)}.
\]

D è la distanza sorgente–ricevitore nel dominio simulato. Il ritardo è positivo
se il pacchetto segue quello dell'acciaio. Il riferimento evita di scambiare il
tempo del massimo della sorgente per tempo di propagazione. La normalizzazione
della correlazione elimina la dipendenza da un guadagno positivo costante.
Non modifica le onde impiegate dal fit.

Il risultato è la velocità equivalente **dell'intero percorso DDS** per questa
sorgente e questa acquisizione; non è una velocità locale del gouge, una
velocità di fase a frequenza singola, né una misura della velocità dello slip.
Il riferimento non rende unica l'interpretazione dei singoli profili.

## Esecuzione

Estrai il pacchetto in una sottocartella di `lab_UW`, quindi da quella
sottocartella esegui:

```bash
poetry run python crea_mappa_simulazioni.py \
  --main ../local_optimization_FWI_velocity_1D.py \
  --results /percorso/della/run/006_reload_ss_1_S.pkl
```

Indica il pickle completo, non il `.analysis.pkl.gz`. Il programma avvia
automaticamente il caricamento dalla cartella del principale: il problema
dei percorsi della sorgente dovuto alla sottocartella è corretto.

Mantieni le impostazioni di preprocessing e sorgente della run originale.
Non serve `installa.py`. Non vengono modificate le inversioni salvate né
eseguiti gradienti o nuove inversioni. Il solo nuovo forward è il riferimento
omogeneo, per ciascuna geometria distinta.

## Risultati

Nella cartella `<nome_pickle>_mappe_simulazioni`, accanto al pickle, rimangono
le quattro mappe dati/simulazioni/residui della versione precedente e vengono
aggiunti:

- **`velocita_effettiva.png`**: stress, tempo efficace, velocità da dati e
  sintetici, errore di arrivo fra sintetico e dato.
- **`velocita_effettiva.csv`**: tutte le quantità e le correlazioni con il
  riferimento, una riga per inversione.
- **`velocita_effettiva.npz`**: tracce, riferimento in acciaio e sorgente S
  realmente usata, oltre ai risultati e alla meccanica. **È il file da
  passarmi per completare e discutere il confronto qui**, senza caricare il
  pickle grande o i TSV originali.
- `velocita_effettiva_metodo.json`: definizione, geometrie, passo numerico
  del riferimento e confronto fra gli arrivi osservati e simulati.

Non si interpolano nuovi profili né nuovi forward negli intervalli saltati.
I punti sono le inversioni effettive. Il confronto dello stress usa l'ipotesi
di rescaling già concordata; il calcolo del ritardo acustico in µs non dipende
da tale scelta di clock meccanico.

## Verifiche e limiti

Sono passate 16 verifiche automatiche su estrazione, esclusione delle onde
riutilizzate, segno del ritardo, ritardi frazionari, invarianza rispetto al
guadagno, conversione in velocità, generazione delle mappe e isolamento del
percorso di ottimizzazione.

È stato inoltre eseguito il solver su un mezzo uniforme di velocità nota
2.800 m/s. Il metodo restituisce 2.799,094 m/s sulla griglia da 251 nodi e
2.799,949 m/s sulla griglia da 501 nodi: l'errore diminuisce raffinando la
griglia. Il caso è sintetico e non quantifica l'errore dei dati sperimentali.
Un controllo dell'intera esportazione e del grafico su quattro mezzi uniformi
è conservato in `verifica_integrazione.json`.

La correlazione segue il pacchetto dominante: se la forma d'onda cambia fino
a produrre massimi concorrenti, l'associazione va controllata nelle mappe.
Il sovracampionamento della correlazione è un'operazione numerica; non
costituisce un'incertezza o una prova di risoluzione temporale.

**Il calcolo sperimentale non è ancora eseguito qui:** il file analysis caricato
ha rimosso i sintetici; il solo `stf.h5` disponibile contiene sorgenti P e non la
`s_70V_100nm` della run. I numeri di 2.800 m/s sopra sono soltanto verifiche.
Il pacchetto usa invece sul tuo computer la sorgente S del tuo principale e
salva tutto il necessario nel nuovo NPZ.

Per ripetere i controlli:

```bash
python3 -m unittest -v verifica_velocita verifica_mappa
python3 verifica_forward_uniforme.py ../lab_uw/simulation_setup.py ../lab_uw/fd1d.py
```
