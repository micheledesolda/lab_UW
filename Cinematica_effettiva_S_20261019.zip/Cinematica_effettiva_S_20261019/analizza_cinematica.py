#!/usr/bin/env python3
"""Confronto riproducibile della cinematica di dati e sintetici accettati.

Uso: python3 analizza_cinematica.py [tracce_per_confronto.npz]
Richiede numpy, scipy, matplotlib. Non esegue inversioni né nuovi forward.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import numpy as np
from scipy.fft import next_fast_len
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def packet_delay(signal, reference, dt_us, oversample=32):
    """Massimo positivo della correlazione lineare; positivo = arrivo dopo.

    Denominatore costante nei lag; nessun riallineamento dei dati originali.
    Lo zero padding interpola la correlazione, senza stimarne l'incertezza.
    """
    a=np.asarray(signal,float); b=np.asarray(reference,float)
    if a.ndim != 1 or a.shape != b.shape or len(a)<4:
        raise ValueError('Dimensioni delle tracce incompatibili')
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError('Valori non finiti')
    den=np.linalg.norm(a)*np.linalg.norm(b)
    if den<=0: raise ValueError('Traccia nulla')
    n=next_fast_len(2*len(a)-1)
    if n%2: n+=1
    sp=np.fft.rfft(a,n)*np.conj(np.fft.rfft(b,n))
    if oversample>1: sp[-1]*=.5
    count=n*oversample
    corr=np.fft.irfft(sp,n=count)*oversample/den
    idx=np.arange(count)
    lag=np.where(idx<=count//2,idx,idx-count)*dt_us/oversample
    valid=np.flatnonzero(np.abs(lag)<=(len(a)-1)*dt_us)
    k=valid[np.argmax(corr[valid])]
    left=(k-1)%count; right=(k+1)%count
    cur=corr[left]-2*corr[k]+corr[right]
    frac=0. if cur>=0 else .5*(corr[left]-corr[right])/cur
    frac=float(np.clip(frac,-.5,.5))
    return float(lag[k]+frac*dt_us/oversample),float(corr[k])


def delays(a,ref,dt):
    return np.array([packet_delay(y,ref,dt) for y in a])


def write_csv(path,header,rows):
    with path.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)


def main():
    base=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input',nargs='?',type=Path,default=base/'tracce_per_confronto.npz')
    args=ap.parse_args()
    p=np.load(args.input,allow_pickle=False)
    cfg=json.loads((base/'contesto.json').read_text())
    t=p['time_us']; slow=p['time_rescaled_s']; rec=p['rec_n']
    a=p['observed']; s=p['synthetic']; dt=float(np.median(np.diff(t)))
    assert a.shape==s.shape==(len(slow),len(t))
    assert np.allclose(np.diff(t),dt,rtol=1e-8,atol=1e-12)
    assert np.all(np.diff(slow)>0)
    # Un riferimento comune a entrambe le famiglie conserva il bias iniziale.
    d=delays(a,a[0],dt); m=delays(s,a[0],dt)
    paired=np.array([packet_delay(x,y,dt) for x,y in zip(s,a)])
    own=delays(s,s[0],dt)
    geom_map=dict(zip(cfg['geometric_rec_n'],cfg['geometric_T_us']))
    geom=np.array([geom_map[int(r)] for r in rec]); geom-=geom[0]
    events=cfg['events']; cycles=[]
    for e in events:
        il=np.flatnonzero((slow>=e['start_s'])&(slow<=e['peak_s']))
        ir=np.flatnonzero((slow>e['peak_s'])&(slow<=e['end_observed_s']))
        assert len(il)>=3 and len(ir)>=3
        i0=il[:3];i1=il[-3:];i2=ir[-3:]
        row=dict(e)
        row.update(start_rec_n=rec[i0].tolist(),pre_rec_n=rec[i1].tolist(),post_rec_n=rec[i2].tolist())
        row['post_time_s']=slow[i2].tolist()
        for name,z in [('data',d[:,0]),('model',m[:,0]),('elastic',geom)]:
            row[name+'_loading_ns']=float(1000*(np.median(z[i1])-np.median(z[i0])))
            row[name+'_release_ns']=float(1000*(np.median(z[i2])-np.median(z[i1])))
        row['last_pre_peak_gap_s']=float(e['peak_s']-slow[il[-1]])
        row['first_post_peak_gap_s']=float(slow[ir[0]]-e['peak_s'])
        cycles.append(row)
    sensitivity=[]
    for lo,hi in [(0,25),(20,25),(20,23),(20,22.7)]:
        mask=(t>=lo)&(t<=hi)
        dd=delays(a[:,mask],a[0,mask],dt)
        mm=delays(s[:,mask],a[0,mask],dt)
        sensitivity.append(dict(window_us=[lo,hi],correlation=float(np.corrcoef(dd[:,0],mm[:,0])[0,1]),
            median_abs_common_reference_difference_ns=float(1000*np.median(abs(mm[:,0]-dd[:,0]))),
            p95_abs_common_reference_difference_ns=float(1000*np.percentile(abs(mm[:,0]-dd[:,0]),95))))
    # Serie densa: stessa finestra 20-24.96 us per tutti i dati, senza sintetici interpolati.
    tw=p['dense_window_time_us']; mask=(t>=tw[0]-1e-8)&(t<=tw[-1]+1e-8)
    assert np.allclose(t[mask],tw)
    dense=delays(p['dense_observed_window'],a[0,mask],dt)
    pair_idx=[int(np.flatnonzero(rec==r)[0]) for r in [347530,347737]]
    i,j=pair_idx
    pair=dict(rec_n=[int(rec[i]),int(rec[j])],
        elastic_difference_ns=float(1000*(geom[j]-geom[i])),
        data_difference_ns=float(1000*packet_delay(a[j],a[i],dt)[0]),
        model_difference_ns=float(1000*packet_delay(s[j],s[i],dt)[0]))
    summary=dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
        n_inversions=len(rec),acoustic_sample_us=dt,acoustic_window_us=[float(t[0]),float(t[-1])],
        reference_rec_n=int(rec[0]),method='Correlazione lineare normalizzata con prima onda registrata: stesso riferimento per dati e modelli.',
        rescaling=cfg['clock'],delay_curve_correlation=float(np.corrcoef(d[:,0],m[:,0])[0,1]),
        data_range_ns=float(1000*np.ptp(d[:,0])),model_range_ns=float(1000*np.ptp(m[:,0])),
        median_abs_common_reference_difference_ns=float(1000*np.median(abs(m[:,0]-d[:,0]))),
        p95_abs_common_reference_difference_ns=float(1000*np.percentile(abs(m[:,0]-d[:,0]),95)),
        median_abs_paired_delay_ns=float(1000*np.median(abs(paired[:,0]))),
        p95_abs_paired_delay_ns=float(1000*np.percentile(abs(paired[:,0]),95)),
        max_abs_paired_delay_ns=float(1000*np.max(abs(paired[:,0]))),
        min_paired_correlation=float(paired[:,1].min()),
        own_reference_curve_correlation=float(np.corrcoef(d[:,0],own[:,0])[0,1]),
        own_reference_median_abs_curve_difference_ns=float(1000*np.median(abs(d[:,0]-own[:,0]))),
        cycles=cycles,window_sensitivity=sensitivity,pair_example=pair,
        interpretation='Ritardi del pacchetto nella banda e finestra registrate. Nessuna nuova inversione. La correlazione elevata dimostra accordo cinematico su queste tracce, non unicità dei profili o ripetibilità su nuove inversioni.',
        absolute_calibration_available=False,
        absolute_calibration_missing='Il file non contiene sorgente S, riferimento omogeneo o un tempo assoluto di propagazione calibrato. Non si assegna T0 dal tempo di picco acquisito né dal vecchio integrale elastico.',
        uncertainty='Le differenze in ns sono discrepanze fra stime numeriche; non incertezze sperimentali. Campionamento originale 40 ns; interpolazione della correlazione x32.')
    (base/'risultati.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
    write_csv(base/'ritardi_117.csv',
        ['rec_n','time_rescaled_s','data_delay_us','model_delay_us','model_minus_data_common_reference_ns',
         'paired_model_minus_data_ns','correlation_data_reference','correlation_model_reference',
         'correlation_model_data','elastic_delay_us'],
        zip(rec,slow,d[:,0],m[:,0],1000*(m[:,0]-d[:,0]),1000*paired[:,0],d[:,1],m[:,1],paired[:,1],geom))
    write_csv(base/'tre_cicli.csv',
        ['cycle','data_loading_ns','model_loading_ns','data_release_ns','model_release_ns','elastic_release_ns','right_censored'],
        [[c[k] for k in ['cycle','data_loading_ns','model_loading_ns','data_release_ns','model_release_ns','elastic_release_ns','right_censored']] for c in cycles])
    np.savez_compressed(base/'ritardi_effettivi.npz',rec_n=rec,time_rescaled_s=slow,
        data_delay_us=d[:,0],model_delay_us=m[:,0],paired_error_ns=1000*paired[:,0],
        geometric_delay_us=geom,dense_time_rescaled_s=p['dense_time_rescaled_s'],
        dense_data_delay_us=dense[:,0],dense_correlation=dense[:,1])
    plot(base,p,d,m,paired,geom,events,dense)
    print(json.dumps({k:v for k,v in summary.items() if k in ['n_inversions','delay_curve_correlation','median_abs_paired_delay_ns','p95_abs_paired_delay_ns','pair_example','absolute_calibration_available']},indent=2))


def plot(base,p,d,m,paired,geom,events,dense):
    plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
    slow=p['time_rescaled_s']; mt=p['mechanical_time_s']; stress=p['shear_stress_MPa']
    dc='#1763ad'; mc='#d95723'; gc='#888888'
    fig,ax=plt.subplots(4,1,figsize=(13,11),sharex=True,layout='constrained',height_ratios=[1,1.6,1.6,1])
    ax[0].plot(mt,stress,color='#222222',lw=1);ax[0].set_ylabel('Stress di taglio\n[MPa]')
    ax[1].plot(p['dense_time_rescaled_s'],1000*dense[:,0],color='#a7bed3',lw=.6,alpha=.8,label='Dati: tutte le onde, 20–25 µs')
    ax[1].plot(slow,1000*d[:,0],color=dc,lw=1.4,label='Dati alle 117 inversioni',zorder=3)
    ax[1].plot(slow,1000*m[:,0],'o',mfc='none',mec=mc,ms=4,label='Sintetici accettati',zorder=4)
    ax[1].set_ylabel('Ritardo del pacchetto\nrispetto alla prima onda [ns]');ax[1].legend(loc='upper left',fontsize=10)
    ax[2].plot(slow,1000*geom,color=gc,lw=.8,alpha=.8,label='Vecchio integrale elastico ∫dz/v')
    ax[2].plot(slow,1000*(m[:,0]-m[0,0]),color=mc,lw=1.4,label='Ritardo dal sintetico completo')
    ax[2].set_ylabel('Variazione del tempo\nrispetto al primo modello [ns]');ax[2].legend(loc='upper left',fontsize=10)
    ax[3].plot(slow,1000*paired[:,0],'.-',color='#6f408e',ms=4,lw=.7)
    ax[3].axhline(0,color='k',lw=.7);ax[3].set_ylabel('Ritardo sintetico − dato\nmisurato coppia per coppia [ns]')
    ax[3].set_xlabel('Tempo meccanico [s] — riscalatura dai due sync')
    for a in ax:
        a.set_xlim(slow[0],slow[-1]);a.grid(alpha=.18)
        for e in events:
            a.axvline(e['peak_s'],color='#bd3030',ls='--',lw=.8)
            a.axvspan(e['peak_s'],min(e['end_observed_s'],slow[-1]),color='#bd3030',alpha=.07)
    fig.suptitle('La cinematica ciclica è riprodotta dai sintetici\n'
                 'Ritardi dalla forma d’onda completa; nessun nuovo forward o riallineamento delle tracce',fontsize=15)
    fig.savefig(base/'cinematica_completa.png',dpi=170);plt.close(fig)
    fig,ax=plt.subplots(2,3,figsize=(14,7),sharex='col',layout='constrained',height_ratios=[1,2])
    for j,e in enumerate(events):
        lo=e['start_s'];hi=min(e['end_observed_s'],slow[-1]);peak=e['peak_s']
        ix=np.flatnonzero((slow>=lo)&(slow<=peak))[-3:]
        off_d=np.median(d[ix,0]);off_m=np.median(m[ix,0])
        sel=(mt>=lo)&(mt<=hi)
        ax[0,j].plot(mt[sel]-peak,stress[sel],color='#222222',lw=1.2)
        ax[0,j].set_title(f'Ciclo {j+1}'+(' — rilascio parziale' if j==2 else ''))
        sel=(slow>=lo)&(slow<=hi)
        ds=p['dense_time_rescaled_s'];di=(ds>=lo)&(ds<=hi)
        dense_offset=np.median(np.interp(slow[ix],ds,dense[:,0]))
        ax[1,j].plot(ds[di]-peak,1000*(dense[di,0]-dense_offset),color=dc,lw=1.3,label='Dati: tutte le onde')
        ax[1,j].plot(slow[sel]-peak,1000*(d[sel,0]-off_d),'.',color=dc,ms=4)
        ax[1,j].plot(slow[sel]-peak,1000*(m[sel,0]-off_m),'o',mfc='none',mec=mc,ms=5,label='Sintetici')
        # Nessun segmento fra modelli: evita anticipi grafici negli intervalli saltati.
        for a in ax[:,j]:
            a.axvline(0,color='#bd3030',ls='--',lw=.9)
            a.axvspan(0,hi-peak,color='#bd3030',alpha=.07)
            a.grid(alpha=.18);a.set_xlim(lo-peak,hi-peak)
        ax[1,j].axhline(0,color='k',lw=.5);ax[1,j].set_xlabel('Tempo dal massimo dello stress [s]')
    ax[0,0].set_ylabel('Stress [MPa]');ax[1,0].set_ylabel('Ritardo rispetto al livello\nprima del rilascio [ns]')
    ax[1,0].legend(fontsize=10)
    fig.suptitle('In tutti e tre i cicli: anticipo durante il caricamento, ritardo durante il rilascio\n'
                 'Zero = mediana delle ultime tre inversioni prima del massimo, per ciascuna curva',fontsize=14)
    fig.savefig(base/'tre_cicli_ritardi.png',dpi=170);plt.close(fig)


if __name__=='__main__':
    main()
