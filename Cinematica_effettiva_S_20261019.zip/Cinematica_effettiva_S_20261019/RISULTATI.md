# Cinematica delle onde S: confronto fra dati e sintetici accettati

Analisi del 19 ottobre 2026, file `006_reload_ss_1_S`, 117 inversioni effettive.

**I sintetici riproducono il ciclo cinematico presente nelle onde registrate:**
anticipo degli arrivi durante il caricamento, ritardo durante il rilascio.
La curva ottenuta dal solo integrale elastico non rappresentava questa
cinematica. Le conclusioni precedenti sulla mancata presenza del ciclo nei
modelli devono quindi essere corrette.

## Che cosa è stato calcolato

L'input `tracce_per_confronto.npz` contiene 117 tracce osservate e 117 sintetici
già accettati, con 625 campioni a 0,04 µs; l'intervallo acquisito è 0–24,96 µs.
Sono inoltre disponibili 12.866 onde registrate nella finestra 20–24,96 µs e la
meccanica sincronizzata. Non sono stati eseguiti nuovi forward o inversioni.

Si usa come riferimento comune la prima onda registrata, record 334906.
Per ciascuna traccia y si misura il ritardo che massimizza

\[
C_y(\delta)=
\frac{\int y(u)\,d_0(u-\delta)\,du}{\|y\|_2\|d_0\|_2},
\qquad
\Delta T_y=\mathop{\rm argmax}_\delta C_y(\delta).
\]

Un ritardo positivo significa arrivo successivo al riferimento. Il denominatore
è costante al variare del ritardo. La correlazione è lineare, senza avvolgimento
circolare delle tracce. Lo zero padding nello spettro interpola la correlazione
di un fattore 32, seguito da interpolazione parabolica locale. I segnali usati
dalla run non sono riallineati o modificati.

Si calcola separatamente anche il ritardo diretto fra ogni sintetico e il suo
dato, usando quest'ultimo come riferimento. Questo distingue l'accordo fra
le traiettorie dall'eventuale offset del primo sintetico.

## Accordo osservato

| Quantità | Valore |
|---|---:|
| Correlazione fra le due curve di ritardo, riferimento comune | 0,999866 |
| Escursione del ritardo nei dati | 166,59 ns |
| Escursione del ritardo nei sintetici | 167,07 ns |
| Differenza assoluta mediana fra le due curve, riferimento comune | 0,60 ns |
| Ritardo assoluto mediano sintetico–dato, coppia per coppia | 0,42 ns |
| 95° percentile del ritardo assoluto, coppia per coppia | 1,32 ns |
| Massimo ritardo assoluto, coppia per coppia | 1,82 ns |

La correlazione delle curve include la deriva complessiva e non è da sola una
prova della componente ciclica. La figura dedicata ai tre episodi e i valori
seguenti verificano direttamente anche quella componente.

Per ogni ciclo si confrontano le mediane delle prime tre e delle ultime tre
inversioni nel caricamento; per il rilascio si confrontano le ultime tre prima
del massimo con le ultime tre disponibili nella fase di rilascio. Le liste dei
record e i tempi effettivi sono in `risultati.json`. Il terzo rilascio è osservato
solo in parte.

| Ciclo | Caricamento, dati [ns] | Caricamento, sintetici [ns] | Rilascio, dati [ns] | Rilascio, sintetici [ns] | Rilascio, integrale elastico [ns] |
|---|---:|---:|---:|---:|---:|
| 1 | −13,45 | −13,07 | +42,90 | +41,53 | +35,82 |
| 2 | −17,03 | −16,56 | +31,57 | +33,71 | +12,62 |
| 3, parziale | −11,51 | −11,72 | +30,33 | +30,78 | +2,38 |

Il segno si ripete in tutti e tre gli episodi e gli ordini di grandezza dei
ritardi dei dati e dei modelli coincidono. Il vecchio integrale attenuava molto
il secondo e soprattutto il terzo rilascio e introduceva oscillazioni spurie
rispetto alla cinematica delle tracce.

Un esempio già discusso è il confronto fra i record 347530 e 347737. Misurando
direttamente il secondo rispetto al primo si ottiene:

| Stimatore | Differenza temporale |
|---|---:|
| Integrale elastico completo ∫dz/v | +132,27 ns |
| Correlazione delle onde registrate | +28,50 ns |
| Correlazione dei sintetici completi | +27,89 ns |

Non si tratta quindi di una perdita del ciclo nelle simulazioni. Le differenze
dei profili che producevano 132 ns nell'indicatore elastico producono circa
28 ns nella propagazione completa effettivamente utilizzata dal fit.

## Perché l'integrale elastico falliva

La velocità salvata c=√(G/ρ) è un parametro del termine elastico. Il solver
implementa invece l'operatore con G=ρc² ed η=ρν, incluse densità variabile e
interfacce. Il suo trasferimento H dipende dall'insieme di questi coefficienti.

Nel mezzo Kelvin–Voigt locale, con convenzione temporale exp(iωt),

\[
k(\omega,z)=\omega\sqrt{\frac{\rho(z)}{G(z)+i\omega\eta(z)}}.
\]

L'integrale ∫dz/c elimina questa dipendenza della fase dalla viscosità e non
include il trasferimento completo attraverso le interfacce. Anche sommare le
fasi locali a una frequenza arbitraria rimarrebbe una riduzione del forward.

Se Q è la sorgente della run, ciascun sintetico si scrive schematicamente
S_i(ω)=A_i Q(ω) H_i(ω), con A_i un eventuale guadagno positivo. La correlazione
dei sintetici accettati utilizza la fase del trasferimento completo e pesa le
frequenze secondo le forme d'onda effettive. Il guadagno scalare non può
produrre un anticipo o un ritardo e viene eliminato dalla normalizzazione.

Il confronto attuale dimostra la discrepanza fra la riduzione elastica e il
forward completo. Non separa quantitativamente quanto di questa discrepanza
derivi dalla viscosità, dalle interfacce o dalla redistribuzione spettrale:
questa attribuzione richiederebbe forward controllati modificando un fattore
alla volta. Non occorre quell'attribuzione per concludere che il ciclo è
riprodotto dai modelli accettati.

## Ritardo misurato e velocità assoluta

I risultati sopra sono ritardi relativi del pacchetto, nella banda e nella
finestra della run. Per trasformarli in una velocità operativa dell'intero
percorso DDS occorre un tempo di riferimento calibrato:

\[
T_{\rm eff,i}=D/c_{\rm acciaio}+\Delta T_{i,\rm acciaio},
\qquad
v_{\rm eff,i}=D/T_{\rm eff,i}.
\]

Il riferimento in acciaio deve essere un forward sulla stessa geometria, con
la stessa sorgente S. Nel modello salvato D=6,3292818246 cm; questa lunghezza
è nota, mentre il nuovo file non contiene né quel riferimento né la sorgente.
Non si può convertire il tempo del massimo acquisito in un tempo assoluto di
propagazione senza tenere conto dell'istante e della forma della sorgente.
Non viene usato il vecchio integrale elastico per assegnare lo zero mancante.

La cartella `calibrazione_assoluta` contiene l'esportatore già preparato nella
chat precedente: usa il pickle completo e la sorgente sul computer della run,
aggiunge un riferimento omogeneo per geometria e salva `velocita_effettiva.npz`.
Il calcolo assoluto sperimentale non è stato eseguito qui. Questa limitazione
non modifica il confronto dei ritardi relativi, ora completato.

## Controlli e limiti

L'accordo resta elevato usando 20–25, 20–23 e 20–22,7 µs: non dipende dalla sola
coda della traccia. Il confronto analitico con un pacchetto traslato di 117 ns,
moltiplicato per 3,1, verifica segno, ritardo frazionario e indipendenza dal
guadagno. L'aumento dell'interpolazione da 16 a 64 modifica i ritardi di quattro
coppie controllate di meno di 0,00015 ns; è una verifica numerica, non un limite
alla risoluzione sperimentale.

Le discrepanze di 0,42 e 1,32 ns descrivono l'accordo fra stime sui dati e sui
sintetici. Non sono errori statistici sulla velocità e non implicano una
risoluzione sperimentale subnanosecondo. Il passo acustico originale è 40 ns.

I massimi dello stress e le fasi usano la riscalatura già concordata dei due
sync, senza adattare un ritardo alla curva acustica. Il calcolo dei ritardi
acustici non dipende da quella riscalatura; la loro attribuzione al caricamento
o al rilascio sì. Negli ultimi due cicli restano intervalli senza nuove
inversioni immediatamente prima del massimo. Nella figura dei cicli i sintetici
sono quindi mostrati solo come punti; la linea continua proviene da tutte le
onde registrate. Non si anticipano graficamente le transizioni interpolando
fra modelli lontani.

Questa analisi verifica la cinematica delle tracce utilizzate dal fit. Non
stabilisce l'unicità dei profili, la ripetibilità invertendo nuovamente la stessa
onda o una capacità di prevedere il prossimo stress drop.

## Riproduzione

Eseguire nella cartella estratta:

```bash
python3 analizza_cinematica.py
```

Richiede NumPy, SciPy e Matplotlib. Rigenera entrambe le figure, i CSV, il file
compatto dei ritardi e il riepilogo JSON. `contesto.json` conserva eventi,
riscalatura e tempi geometrici estratti dal file analysis nella chat precedente.
Lo SHA-256 dell'input corrente è salvato in `risultati.json`.
