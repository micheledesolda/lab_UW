#!/usr/bin/env python3
"""Velocità del pacchetto nella banda della sorgente, da tracce complete.

Una traccia di riferimento attraversa lo stesso dominio reso omogeneo in
acciaio. Il ritardo relativo al riferimento viene aggiunto a D/c_acciaio.
Non si identifica questo indicatore operativo con una velocità locale o con
la velocità di gruppo a una frequenza scelta.
"""
from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np
from scipy.fft import next_fast_len


def packet_delay(signal, reference, dt_us, oversample=32):
    """Ritardo positivo se signal segue reference; stessa polarità.

    Correlazione lineare, interpolata nello spettro. La normalizzazione è
    indipendente dal ritardo: nessun adattamento dell'ampiezza entra in T.
    L'interpolazione non costituisce una stima dell'incertezza temporale.
    """
    a=np.asarray(signal,float).reshape(-1)
    b=np.asarray(reference,float).reshape(-1)
    if len(a)!=len(b) or len(a)<4 or dt_us<=0:
        raise ValueError('Tracce o passo acustico non validi.')
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError('Tracce con valori non finiti.')
    denom=np.linalg.norm(a)*np.linalg.norm(b)
    if denom<=0:raise ValueError('Traccia nulla: ritardo non definibile.')
    if int(oversample)!=oversample or oversample<1:
        raise ValueError('Fattore numerico di sovracampionamento non valido.')
    n=next_fast_len(2*len(a)-1)
    if n%2:n+=1
    spectrum=np.fft.rfft(a,n)*np.conj(np.fft.rfft(b,n))
    # Nel sovracampionamento di una sequenza reale il vecchio bin Nyquist
    # deve essere diviso fra le nuove frequenze positive e negative.
    if oversample>1:spectrum[-1]*=.5
    count=n*int(oversample)
    corr=np.fft.irfft(spectrum,n=count)*oversample/denom
    index=np.arange(count)
    lag=np.where(index<=count//2,index,index-count)*dt_us/oversample
    valid=np.abs(lag)<=(len(a)-1)*dt_us
    eligible=np.flatnonzero(valid)
    peak=eligible[np.argmax(corr[eligible])]
    # Interpolazione parabolica residua entro i tre campioni della correlazione.
    left=(peak-1)%count;right=(peak+1)%count
    curvature=corr[left]-2*corr[peak]+corr[right]
    fraction=0. if curvature>=0 else .5*(corr[left]-corr[right])/curvature
    fraction=float(np.clip(fraction,-.5,.5))
    delay=float(lag[peak]+fraction*dt_us/oversample)
    return delay,float(corr[peak])


def convert_delay(distance_cm, reference_speed_cm_us, delay_us):
    distance=np.asarray(distance_cm,float)
    time=distance/reference_speed_cm_us+np.asarray(delay_us,float)
    if np.any(time<=0):raise ValueError('Tempo efficace non positivo: controllare associazione del pacchetto.')
    return time,1e4*distance/time


def reference_trace(namespace, context, axis_cm, global_row):
    """Un solo forward omogeneo per geometria; nessun gradiente/FWI."""
    p=context['params'];assembly=context['assembly_dict'];handler=context['stf_handler']
    if p.get('embedding_mode')!='effective_surface' or p.get('source_injection')!='body_force' or p.get('receiver_quantity')!='velocity':
        raise ValueError('Il riferimento implementato richiede effective_surface, body_force e receiver velocity.')
    x=np.asarray(axis_cm,float);dx=float(x[1]-x[0])
    if np.any(np.diff(x)<=0) or not np.allclose(np.diff(x),dx,rtol=1e-8,atol=1e-12):
        raise ValueError('Griglia salvata non uniforme.')
    config=dict(p.get('source_receiver_config') or {})
    source_position=float(config.get('source_position_cm',x[0]))
    receiver_position=float(config.get('receiver_position_cm',x[-1]))
    distance=receiver_position-source_position
    if distance<=0:raise ValueError('Distanza sorgente–ricevitore non positiva.')
    wave_type=assembly['wave_type']
    speed=float(assembly['side1_params']['velocity'+wave_type])
    rho=float(p.get('side1_density_g_cm3',p.get('steel_density_g_cm3',7.85)))
    time_us=np.asarray(context['uw_data_handler'].metadata['time_ax_waveform'],float)
    if not np.isclose(time_us[0],0.,atol=1e-10):
        raise ValueError('Il riferimento richiede l’asse acustico originale a partire da zero.')
    saved_runtime=(global_row or {}).get('analysis_runtime') or {}
    simulation_info=saved_runtime.get('simulation') or {}
    max_alpha=float(simulation_info.get('maximum_damping') or (global_row or {}).get('best_gouge_damping') or 0.)
    max_speed=max(speed,float(p.get('max_velocity2simulate') or speed))
    timing=namespace['SimulationTime'](observed_time=time_us,dx=dx,max_velocity=max_speed,max_alpha=max_alpha)
    radius=int(config.get('interpolation_radius_cells',4))
    source=namespace['Source1D'](
        stf_time=np.asarray(handler.metadata['time_ax_waveform'],float),
        stf_waveform=np.asarray(handler.waveform_data,float).reshape(-1),
        position=source_position,pzt_layer_width=0.,
        radius=int(config.get('source_radius_cells',radius)),
        extension=float(config.get('source_extension_cm',0.)),
        normalization=config.get('source_normalization','integral'),
        boundary_mode=config.get('spatial_boundary_mode','truncate'))
    receiver=namespace['Receiver1D'](
        position=receiver_position,pzt_layer_width=0.,
        radius=int(config.get('receiver_radius_cells',radius)),
        extension=float(config.get('receiver_extension_cm',0.)),
        normalization=config.get('receiver_normalization','sum'),
        boundary_mode=config.get('spatial_boundary_mode','truncate'))
    source.interpolate_time_function(dt=timing.dt,simulation_time=timing.simulation_time)
    source.create_spatial_function(spatial_axis=x,dx=dx)
    receiver.create_spatial_function(spatial_axis=x,dx=dx)
    native=namespace['finite_difference_1d_receiver_trace'](
        num_x=len(x),delta_x=dx,num_t=timing.num_t,delta_t=timing.dt,
        source_spatial_function=source.spatial_function,
        source_time_function=source.time_function,
        receiver_spatial_function=receiver.spatial_function,
        receiver_quantity='velocity',velocity_model=np.full(len(x),speed),
        damping_model=np.zeros(len(x)),density_model=np.full(len(x),rho),
        boundary_condition=p.get('boundary_condition','free'),
        boundary_impedance=p.get('boundary_impedance'),source_injection='body_force')
    trace=np.interp(time_us,timing.simulation_time,native)
    return dict(trace=trace,distance_cm=distance,speed_cm_us=speed,
                physical_time_us=distance/speed,native_dt_us=float(timing.dt))


def add_effective_velocity(namespace,context,selected,args,output):
    output=Path(output)
    source=np.load(output/'tracce_per_confronto.npz',allow_pickle=False)
    acoustic=np.asarray(source['time_us'],float)
    dt=float(np.median(np.diff(acoustic)))
    if not np.allclose(np.diff(acoustic),dt,rtol=1e-7,atol=1e-10):
        raise ValueError('Campionamento acustico non uniforme.')
    observed=source['observed'];synthetic=source['synthetic'];slow=source['time_rescaled_s'];records=source['rec_n']
    references={};rows=[];reference_signals=[]
    for i,item in enumerate(selected):
        axis=item.get('x_axis_cm')
        if axis is None:raise ValueError('Asse spaziale non disponibile nella riga salvata.')
        x=np.asarray(axis,float)
        key=(len(x),float(x[0]),float(x[-1]),float(x[1]-x[0]))
        if key not in references:
            print(f'Riferimento acciaio: {len(x)} nodi, L={x[-1]-x[0]:.8g} cm; un forward.',flush=True)
            references[key]=reference_trace(namespace,context,x,getattr(args,'global_row',None))
        ref=references[key]
        ds,cs=packet_delay(synthetic[i],ref['trace'],dt)
        dd,cd=packet_delay(observed[i],ref['trace'],dt)
        ts,vs=convert_delay(ref['distance_cm'],ref['speed_cm_us'],ds)
        td,vd=convert_delay(ref['distance_cm'],ref['speed_cm_us'],dd)
        rows.append([int(records[i]),float(slow[i]),ref['distance_cm'],float(ts),float(td),
                     float(vs),float(vd),float(ts-td),cs,cd])
        reference_signals.append(ref['trace'])
    array=np.array(rows,float)
    with (output/'velocita_effettiva.csv').open('w',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(['rec_n','time_rescaled_s','distance_cm','T_packet_model_us','T_packet_data_us',
                         'V_packet_model_m_s','V_packet_data_m_s','arrival_error_us',
                         'correlation_model_reference','correlation_data_reference'])
        writer.writerows(rows)
    np.savez_compressed(output/'velocita_effettiva.npz',
        rec_n=records,time_rescaled_s=slow,time_us=acoustic,
        distance_cm=array[:,2],T_model_us=array[:,3],T_data_us=array[:,4],
        V_model_m_s=array[:,5],V_data_m_s=array[:,6],arrival_error_us=array[:,7],
        reference_traces=np.array(reference_signals),synthetic=synthetic,observed=observed,
        stf_time_us=np.asarray(context['stf_handler'].metadata['time_ax_waveform'],float),
        stf_waveform=np.asarray(context['stf_handler'].waveform_data,float).reshape(-1),
        mechanical_time_s=source['mechanical_time_s'],shear_stress_MPa=source['shear_stress_MPa'])
    metadata=dict(method='Ritardo del pacchetto per correlazione con un forward omogeneo in acciaio; T=D/c_acciaio+ritardo, V=D/T.',
        scope='Intero percorso fra sorgente e ricevitore; non velocità locale del solo gouge.',
        interpretation='Velocità operativa del pacchetto per questa sorgente e questa finestra di acquisizione, non una velocità di fase unica per tutte le frequenze.',
        forward_count=len(references),local_inversions=0,acoustic_step_us=dt,
        correlation_oversampling=32,reference_speed_cm_us=[r['speed_cm_us'] for r in references.values()],
        reference_native_dt_us=[r['native_dt_us'] for r in references.values()],
        median_abs_model_data_delay_ns=float(np.median(np.abs(array[:,7]))*1000),
        note='Il sovracampionamento della correlazione non fornisce un’incertezza statistica; controllare l’associazione del pacchetto e le correlazioni riportate.')
    (output/'velocita_effettiva_metodo.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False))
    plot_effective(output,source,array)
    print(f'Velocità effettiva pronta: {output / "velocita_effettiva.csv"}',flush=True)


def plot_effective(output,source,array):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(4,1,figsize=(14,11),sharex=True,layout='constrained')
    ax[0].plot(source['mechanical_time_s'],source['shear_stress_MPa'],color='k',lw=.6)
    ax[0].set_ylabel('Stress [MPa]')
    t=array[:,1]
    for a,j,k,label in [(ax[1],3,4,'Tempo efficace [µs]'),(ax[2],5,6,'V efficace DDS [m/s]')]:
        a.plot(t,array[:,k],'o-',ms=3,lw=.7,color='tab:blue',label='Onde registrate')
        a.plot(t,array[:,j],'o-',ms=3,lw=.7,color='tab:red',label='Simulazioni accettate')
        a.set_ylabel(label);a.legend(fontsize=9)
    ax[3].plot(t,1000*array[:,7],'o-',ms=3,lw=.7,color='tab:purple')
    ax[3].axhline(0,color='k',lw=.7);ax[3].set_ylabel('Errore di arrivo [ns]')
    ax[3].set_xlabel('Tempo meccanico [s] — ipotesi di rescaling dei sync')
    for a in ax:a.grid(alpha=.2);a.set_xlim(t[0],t[-1])
    fig.suptitle('Velocità del pacchetto nella banda della sorgente reale\n'
                 'Ritardo da tracce complete, calibrato sullo stesso percorso omogeneo in acciaio')
    fig.savefig(Path(output)/'velocita_effettiva.png',dpi=180);plt.close(fig)
