# Cinematica S — risultati già calcolati

Aprire `tre_cicli_ritardi.png` per il confronto nei cicli e
`cinematica_completa.png` per l'intera sequenza, il confronto con il vecchio
integrale elastico e il ritardo sintetico–dato. I risultati e le definizioni
complete sono in `RISULTATI.md`.

I ritardi relativi sono già calcolati. Per rigenerarli:

```bash
python3 analizza_cinematica.py
```

Per completare la calibrazione in m/s, copiare la cartella
`calibrazione_assoluta` dentro la propria cartella `lab_UW` ed eseguire da
`lab_UW`:

```bash
poetry run python calibrazione_assoluta/crea_mappa_simulazioni.py \
  --main local_optimization_FWI_velocity_1D.py \
  --results /percorso/della/run/006_reload_ss_1_S.pkl
```

Serve il pickle originale completo e la configurazione della run S, inclusa
la sorgente `s_70V_100nm`. Non occorrono nuove inversioni. L'esportatore salva
`velocita_effettiva.npz`, con sorgente, riferimento omogeneo e tempi calibrati,
nella cartella delle mappe accanto al pickle. Il file caricato in questa chat,
`tracce_per_confronto.npz`, non contiene questi elementi di calibrazione.
